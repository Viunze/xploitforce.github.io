
document.addEventListener("DOMContentLoaded", () => {
  // Smooth scroll
  document.querySelectorAll("a[href^='#']").forEach(anchor => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute("href"));
      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  // Notification ketika user klik executor link
  const executorLinks = document.querySelectorAll(".executor-link");
  executorLinks.forEach(link => {
    link.addEventListener("click", () => {
      showToast("Link Executor Dibuka!");
    });
  });

  function showToast(message) {
    const toast = document.createElement("div");
    toast.textContent = message;
    toast.className = "custom-toast";
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("show");
    }, 100);

    setTimeout(() => {
      toast.classList.remove("show");
      setTimeout(() => document.body.removeChild(toast), 500);
    }, 3000);
  }
});
